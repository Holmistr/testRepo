package org.infinispan.server.test.org.infinispan.server.test.configs;

import org.junit.Test;

/**
 * TODO: document this
 *
 * @author Jiri Holusa (jholusa@redhat.com)
 */
public class ExampleConfigsIT {

    @Test
    public void testJDBCCacheStoreConfig() {
        throw new IllegalArgumentException();
    }
}
