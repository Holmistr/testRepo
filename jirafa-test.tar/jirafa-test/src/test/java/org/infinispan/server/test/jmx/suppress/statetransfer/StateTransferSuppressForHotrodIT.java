package org.infinispan.server.test.jmx.suppress.statetransfer;

import org.junit.Test;

/**
 * TODO: document this
 *
 * @author Jiri Holusa (jholusa@redhat.com)
 */
public class StateTransferSuppressForHotrodIT {

    @Test
    public void testRebalanceSwitch() {
        throw new IllegalArgumentException();
    }
}
