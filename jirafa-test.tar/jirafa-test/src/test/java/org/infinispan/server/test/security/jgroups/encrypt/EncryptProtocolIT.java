package org.infinispan.server.test.security.jgroups.encrypt;

import org.junit.Test;

/**
 * TODO: document this
 *
 * @author Jiri Holusa (jholusa@redhat.com)
 */
public class EncryptProtocolIT {

    @Test
    public void testEncryptProtocolRegistered() {
        throw new IllegalArgumentException();
    }
}
