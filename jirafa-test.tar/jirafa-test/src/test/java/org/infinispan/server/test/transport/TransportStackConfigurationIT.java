package org.infinispan.server.test.transport;

import org.junit.Test;

/**
 * TODO: document this
 *
 * @author Jiri Holusa (jholusa@redhat.com)
 */
public class TransportStackConfigurationIT {

    @Test
    public void testTCPStackAttributes() {
        throw new IllegalArgumentException();
    }

    @Test
    public void testUDPStackAttributes() {
        throw new IllegalArgumentException();
    }
}
