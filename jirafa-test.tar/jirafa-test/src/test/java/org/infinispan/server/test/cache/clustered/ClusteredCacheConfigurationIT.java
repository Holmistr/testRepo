package org.infinispan.server.test.cache.clustered;

import org.junit.Test;

/**
 * TODO: document this
 *
 * @author Jiri Holusa (jholusa@redhat.com)
 */
public class ClusteredCacheConfigurationIT {

    @Test
    public void testQueueSizeHotrod() {
        throw new IllegalArgumentException();
    }
}
