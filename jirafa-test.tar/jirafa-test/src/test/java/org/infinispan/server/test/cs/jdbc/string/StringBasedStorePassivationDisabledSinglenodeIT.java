package org.infinispan.server.test.cs.jdbc.string;

import org.junit.Test;

/**
 * TODO: document this
 *
 * @author Jiri Holusa (jholusa@redhat.com)
 */
public class StringBasedStorePassivationDisabledSinglenodeIT {

    @Test
    public void testPreloadWithoutPurge() {
        throw new IllegalArgumentException();
    }
}
